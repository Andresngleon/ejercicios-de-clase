export class Card {
    constructor(id, icon, isDiscovered = false) {
        this.id = id;
        this.icon = icon;
        this.isDiscovered = isDiscovered;
    }
}